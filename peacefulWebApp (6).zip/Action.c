Action()
{

	lr_start_transaction("1st Page");
	web_reg_find("Search=Body",
		"Text=Welcome to our peaceful application :)",
		LAST);

	web_reg_find("Search=Headers",
		"Text=nginx/1.4.6 (Ubuntu)",
		LAST);

	web_url("15.125.124.107:81", 
		"URL=http://15.125.127.151:81/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(3);
	
	lr_end_transaction("1st Page", LR_AUTO);
	
	
	lr_start_transaction("2nd Page");
	
	web_url("secondPage.html", 
		"URL=http://15.125.127.151:81/secondPage.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(3);
	lr_end_transaction("2nd Page", LR_AUTO);
	
	
	lr_start_transaction("3rd Page");

	web_url("thirdPage.html", 
		"URL=http://15.125.127.151:81/thirdPage.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);
	lr_think_time(4);
	lr_end_transaction("3rd Page", LR_AUTO);
	
	return 0;
}